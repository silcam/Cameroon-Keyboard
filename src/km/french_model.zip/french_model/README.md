French-model keyboard
==============

Version 1.0

Description
-----------
French-model generated from template

Links
-----

Copyright
---------
See [LICENSE.md](LICENSE.md)

Supported Platforms
-------------------
 * Windows
 * macOS
 * Linux
 * Web
 * iPhone
 * iPad
 * Android phone
 * Android tablet
 * Mobile devices
 * Desktop devices
 * Tablet devices

