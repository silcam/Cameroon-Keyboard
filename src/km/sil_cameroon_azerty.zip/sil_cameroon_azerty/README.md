Cameroon AZERTY keyboard
=====================

Copyright (C) 2018-2020 SIL Cameroon

Version 6.0.3

__DESCRIPTION__

This keyboard layout seeks to follow the General Alphabet of Cameroonian Languages. It includes
a touch layout for Android and iOS devices. Full documentation is available in the help files.

Links
-----

 * Help:     <http://help.keyman.com/keyboard/sil_cameroon_azerty>
 * More Info:     <https://LangTechCameroon.info>
 * Contact:  <keyboards_cameroon@sil.org>

Supported Platforms
-------------------
 * Windows
 * MacOS
 * Linux
 * Web
 * Mobile Web
 * iOS
 * Android
