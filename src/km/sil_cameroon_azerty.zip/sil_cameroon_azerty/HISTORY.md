Change History
=======================
6.0.3 (2020-Nov)
-----------------
* Major Update to CSS for compatibility with Keyman 10-14

6.0.2 (2020-Jun-23)
-----------------
* Updated htm files for readability on Linux

6.0.1 (2019)
-----------------
* Updating Documentation and screenshots, Upgrade to Keyman 12

6.0 (2018)
-----------------
* Rewrote Documentation, Enabled external Keyboards with Mobile Clients. Submitted to new Keyman Repository

5.0 (Unreleased)
-----------------
* Optimization of Mobile Keyboards for Keyman 10.

4.0 (2017)
-----------------
* Added Mobile Keyboards

3.0 (2010)
-----------------
* Major Revision of Keyboards

2.0 (2000)
-----------------
* Unicode (Created for MSKLC and Keyman)

Cameroon Keyboard 1.0 (Date Unknown)
-----------------

Non-Unicode

* Created by Jenni Beadle

